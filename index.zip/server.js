/*const express = require('express');
const app = express();
const path = require('path');

app.set("/", "html");
app.use(express.static(path.join(__dirname, "/")));
app.use(express.json());
app.use(express.urlencoded({extended: false}));4

app.get('/', (req, res) => {
    res.render('index');
});

app.listen(8080, () =>{
    console.log("Listening on localhost 8080");
});
*/
const http = require('http')
const port = 8080
  
// Create a server object:
const server = http.createServer(function (req, res) {
    var fs = require('fs');
    // Write a response to the client
    res.write(fs.readFile('index.html'))
  
    // End the response 
    res.end()
})
  
// Set up our server so it will listen on the port
server.listen(port, function (error) {
  
    // Checking any error occur while listening on port
    if (error) {
        console.log('Something went wrong', error);
    }
    // Else sent message of listening
    else {
        console.log('Server is listening on port' + port);
    }
})